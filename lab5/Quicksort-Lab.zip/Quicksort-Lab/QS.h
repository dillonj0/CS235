//
// Created by Dillon Jensen on 14/JUL/2022
//

#ifndef QS_H
#define QS_H

#include <iostream>
#include <string>

#include "QSInterface.h"

using namespace std;

class QS : public QSInterface {
public:
    QS();
    ~QS();
    void sortAll();
    int medianOfThree(int left, int right);
    int partition(int left, int right, int pivotIndex);
    string getArray() const;
    int getSize() const;
    bool addToArray(int value);
    bool createArray(int capacity);
    void clear();

private:
    int *table;
    int nextAdd = 0;
    int tableCapacity = 0; // actual size determined in createArray();
    void swap(int first, int second);
    void quicksort(int first, int last);
};

#endif

