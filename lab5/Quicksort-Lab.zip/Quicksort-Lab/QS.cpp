//
// Created by Lee Jensen on 7/14/22.
//
//#include <string>

#include "QS.h"

QS::QS() {
    cout << "*** IN CONSTRUCTOR ***" << endl;
}
QS::~QS() {
    cout << "*** IN DESTRUCTOR ***" << endl;
    clear();
}

/*
* sortAll()
*
* Sorts elements of the array.  After this function is called, every
* element in the array is less than or equal its successor.
*
* Does nothing if the array is empty.
*/
void QS::sortAll(){
//    cout << "*** IN SORT ALL ***" << endl;
    if (nextAdd == 0){
        // If array size 0:
        return;
    }
    int left = 0;
    int right = nextAdd - 1;
    quicksort(left, right);
//    cout << "*** DONE SORTING ***" << endl;
//    getArray();
}
void QS::quicksort(int first, int last){
    if (last - first < 1){
        return;
    }
    int pivot = medianOfThree(first, last);
    pivot = partition(first, last, pivot);
    quicksort(first, pivot - 1);
    quicksort(pivot + 1, last);
}

int QS::medianOfThree(int left, int right){
//    cout << "*** IN MEDIAN OF THREE ***" << endl;
    if (left == right || left < 0 || right >= nextAdd|| left > right){
        // If array size 0 || l/r out of bounds || l > r:
        return -1;
    }
    int middle = (left + right) / 2;
    // bubble sort LMR:
    if (table[left] > table[middle]){
        swap(left, middle);
    }
    if (table[middle] > table[right]){
        swap(right, middle);
    }
    if (table[left] > table[middle]){
        swap(left, middle);
    }    // After sorting:
//    cout << "L, M, R: " << table[left] << "," << table[middle] << "," << table[right] << endl;
    return middle;
}
void QS::swap(int first, int second){
//    cout << "*** IN SWAP ***" << endl;
//    cout << "First & second: " << table[first] << " & " << table[second] << endl;
    int temp = table[first];
//    cout << "writing first as " << table[second] << endl;
    table[first] = table[second];
//    cout << "writing second as " << temp << endl;
    table[second] = temp;
}

int QS::partition(int left, int right, int pivotIndex){
//    cout << "*** IN PARTITION ***" << endl;
    if (left == right || left < 0 || right >= nextAdd || left > right
        || pivotIndex < left || pivotIndex > right){
        // If array size 0 || l/r/p out of bounds || l > r:
        return -1;
    }
    swap(left, pivotIndex);
    int up = left + 1;
    int down = right;
    do {
        while ((table[up] <= table[left]) && (up < right)){
            up++;
        }
        while ((table[down] > table[left]) && (down > left)){
            down--;
        }
        if (up < down){
            swap(up, down);
        }
    } while (up < down);
    swap(left, down);
    return down;
}

string QS::getArray() const{
//    cout << "*** IN GET ARRAY ***" << endl;
    string arrayAsString;
    if (nextAdd == 0){
        return "";
    }
    for (int i = 0; i < nextAdd; i++){
        arrayAsString = arrayAsString + to_string(table[i]);
        if (i != nextAdd - 1){
            arrayAsString = arrayAsString + ",";
        }
    }
    cout << arrayAsString << endl;
    return arrayAsString;
}

int QS::getSize() const{
//    cout << "*** IN GETSIZE ***" << endl;
    return nextAdd;
}

bool QS::addToArray(int value){
//    cout << "*** IN ADD TO ARRAY ***" << endl;
    if (nextAdd < tableCapacity){
        // If the array is not yet full:
        table[nextAdd] = value;
        nextAdd++;
        return true;
    }
    // If the array is full:
    return false;
}

bool QS::createArray(int capacity){
//    cout << "*** IN CREATE ARRAY ***" << endl;
    if(nextAdd != 0){
        // If the table hasn't already been cleared.
//        cout << "Clearing table... " << endl;
        clear(); //clear table;
    }
    if (capacity < 0){
        //if the given capacity is negative
        return false;
    }
    // otherwise, allocate memory & return true:
    table = new int[capacity];
    tableCapacity = capacity;
    return true;
}

void QS::clear(){
//    cout << "*** IN CLEAR ***" << endl;
        delete [] table;
        table = NULL;
        nextAdd = 0;
}